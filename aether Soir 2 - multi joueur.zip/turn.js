// Relais TURN (facultatif mais recommandé si la connexion directe échoue).
// Remplace les 3 valeurs entre guillemets par celles de ton compte metered.ca
// (ou de n'importe quel fournisseur TURN), puis enregistre le fichier sur GitHub.
window.AEG_ICE=[
  {urls:'turn:global.relay.metered.ca:80',username:'TON_USERNAME',credential:'TON_MOT_DE_PASSE'},
  {urls:'turn:global.relay.metered.ca:80?transport=tcp',username:'TON_USERNAME',credential:'TON_MOT_DE_PASSE'},
  {urls:'turn:global.relay.metered.ca:443',username:'TON_USERNAME',credential:'TON_MOT_DE_PASSE'},
  {urls:'turns:global.relay.metered.ca:443?transport=tcp',username:'TON_USERNAME',credential:'TON_MOT_DE_PASSE'}
];
